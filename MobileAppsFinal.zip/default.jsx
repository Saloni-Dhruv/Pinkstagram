import React, { Component } from 'react';
import { AppRegistry, Text, View, StyleSheet, Image, Dimensions, ScrollView, TouchableHighlight, TextInput } from 'react-native';
import Constants from 'expo-constants';

let deviceHeight = Dimensions.get('window').height;
let deviceWidth = Dimensions.get('window').width;


export default class App extends Component {
    state = {
        signUpPageDisplay: 'block',
        feedPageDisplay: 'none',
        dMPageDisplay: 'none',
        myProfilePageDisplay: 'none',
        inputUsername: 'Enter Your Username',
        inputPassword: 'Enter Your Password',
        
        imageFeed: [],
    };
    
    

    handleSignUpPageDisplay = () => this.setState(state => ({
        signUpPageDisplay: 'block',
        feedPageDisplay: 'none',
        dMPageDisplay: 'none',
        myProfilePageDisplay: 'none',
    }));

    handleFeedPageDisplay = () => this.setState(state => ({
        signUpPageDisplay: 'none',
        feedPageDisplay: 'block',
        dMPageDisplay: 'none',
        myProfilePageDisplay: 'none',
    }));

    handleDMPageDisplay = () => this.setState(state => ({
        signUpPageDisplay: 'none',
        feedPageDisplay: 'none',
        dMPageDisplay: 'block',
        myProfilePageDisplay: 'none',
    }));
    
    handleMyProfilePageDisplay = () => this.setState(state => ({
        signUpPageDisplay: 'none',
        feedPageDisplay: 'none',
        dMPageDisplay: 'none',
        myProfilePageDisplay: 'block',
    }));


    _handleUsernameInput = inputUsername => {
        this.setState({ inputUsername });
    };

    _handlePasswordInput = inputPassword => {
        this.setState({ inputPassword });
    };
    
    


    render() {
        return (
            <View style={styles.container}>
            <Image
             source={{ uri: 'https://codehs.com/uploads/1984184f21c6caa132c13a2541655369' }}
                  style={styles.imageLogo}
              />
            
                <Text style={styles.title}>
                    Instagram
                </Text>
                
                
                
                
                <View style={{ display: this.state.signUpPageDisplay}}>
                    <View style={styles.contentContainer}>
                        <View style={styles.usernameBox}>
                            <TextInput
                                value={this.state.inputUsername}
                                onChangeText={this._handleUsernameInput}
                                style={{ fontSize: 18, textAlign: 'center', marginTop: 5, }}
                            />
                        </View>
                        <View style={styles.passwordBox}>
                            <TextInput
                                value={this.state.inputPassword}
                                onChangeText={this._handlePasswordInput}
                                style={{ fontSize: 18, textAlign: 'center', marginTop: 5, }}
                            />
                        </View>
                    </View>
                </View>
                
                
                <View style={{ display: this.state.feedPageDisplay}}>
                    <View style={styles.contentContainer}>
                            
                    
                    </View>
                </View>
                
                <View style={{ display: this.state.dMPageDisplay}}>
                    <View style={styles.contentContainer}>
                     end/done
                    </View>
                </View>
                
                <View style={{ display: this.state.myProfilePageDisplay}}>
                    <View style={styles.contentContainer}>
                    </View>
                </View>
                
                <View style={styles.taskbar}>
                
                    <TouchableHighlight
                        onPress= {this.handleSignUpPageDisplay}
                    >
                    <View style={styles.signUpButton}>
                        <Text style={styles.signUpButtonText}>
                            Sign Up
                        </Text>
                    </View>
                    </TouchableHighlight>
                    
                    <TouchableHighlight
                        onPress= {this.handleFeedPageDisplay}
                    >
                    <View style={styles.feedButton}>
                        <Text style={styles.feedButtonText}>
                            My Feed
                        </Text>
                    </View>
                    </TouchableHighlight>
                    
                    <TouchableHighlight
                        onPress= {this.handleDMPageDisplay}
                    >
                    <View style={styles.dMButton}>
                        <Text style={styles.dMButtonText}>
                            My DM'S
                        </Text>
                    </View>
                    </TouchableHighlight>
                    
                    <TouchableHighlight
                        onPress={this.handleMyProfilePageDisplay}
                    >
                    <View style={styles.myProfileButton}>
                        <Text style={styles.myProfileButtonText}>
                            My Page
                        </Text>
                    </View>
                    </TouchableHighlight>
                    
                </View>
                
                
                
            </View>
      
            
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        
        //paddingTop: Constants.statusBarHeight,
        backgroundColor: 'pink',
        alignItems: 'center',
    },
    contentContainer: {
        height: (deviceHeight/7) * 7,
        margin: 10,
        color: 'white',
        fontSize: 20,
        //textAlign: 'center',
    },
    usernameBox:{
        height: deviceHeight/12,
        width: deviceWidth/1.25,
        borderColor: 'white',
        borderWidth: 2,
        marginTop: 5,
        marginBottom: 15,
    },
    passwordBox:{
        height: deviceHeight/12,
        width: deviceWidth/1.25,
        borderColor: 'white',
        borderWidth: 2,
        marginTop: 5,
    },
    
    imageLogo: {
      alignItems: 'center',
      justifyContent: 'center',
      height: deviceHeight/10,
      width: deviceWidth/6,
      marginTop: 10,
    },
    
    boxContainer: {
        flexDirection: 'row',
        justifyContent: 'center',
        //alignItems: 'center',
        //justifyContent: 'center',
    },

    box: {
        borderColor: 'white',
        height: deviceHeight/8,
        width: deviceWidth/6,
        borderWidth: 2,
        marginTop: 5,
        borderColor: 'white',
    },
    taskbar: {
        height: deviceHeight/8,
        width: deviceWidth,
        borderWidth: 3,
        borderColor: 'white',
        flexDirection: 'row',
        flexDirection: 'center',
        //marginTop: 20,
        alignItems: 'center',
    },
    signUpButton: {
        height: deviceHeight/10,
        width: deviceWidth/5,
        backgroundColor: 'white',
        borderWidth: 2,
        marginLeft: 11,
    },
    signUpButtonText: {
        textAlign: 'center',
        fontSize: 18,
        fontFamily: 'times new roman',
        fontWeight: 'bold',
    },
    feedButton: {
        height: deviceHeight/10,
        width: deviceWidth/5,
        backgroundColor: 'white',
        borderWidth: 2,
        marginLeft: 10,
    },
    feedButtonText: {
        textAlign: 'center',
        fontSize: 18,
        fontFamily: 'times new roman',
        fontWeight: 'bold',
    },
    dMButton: {
        height: deviceHeight/10,
        width: deviceWidth/5,
        backgroundColor: 'white',
        borderWidth: 2,
        marginLeft: 10,
    },
    dMButtonText: {
        textAlign: 'center',
        fontSize: 18,
        fontFamily: 'times new roman',
        fontWeight: 'bold',
    },
    myProfileButton: {
        height: deviceHeight/10,
        width: deviceWidth/5,
        backgroundColor: 'white',
        borderWidth: 2,
        marginLeft: 10,
    },
    myProfileButtonText: {
        textAlign: 'center',
        fontSize: 18,
        fontFamily: 'times new roman',
        fontWeight: 'bold',
    },
    title: {
        fontSize: 25,
        fontWeight: 'bold',
        textAlign: 'center',
        color: 'white',
        marginTop: 5,
    },
    
});